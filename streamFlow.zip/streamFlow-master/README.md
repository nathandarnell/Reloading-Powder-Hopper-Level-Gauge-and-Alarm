# streamFlow

Simple and light-weight stream operator for Arduino framework.

```c++
Serial<<"Value:"<<value<<endl;

Serial<<"Step 1"<<then;
Serial<<"Step 2"<<endl;

Serial<<dot;
Serial<<dotl;
```
