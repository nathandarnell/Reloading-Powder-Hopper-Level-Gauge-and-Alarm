
#include "streamFlow.h"

StreamFlush go;
endlObj endl;
tabObj tab;
thenObj then;
dotObj dot;
dotlObj dotl;
